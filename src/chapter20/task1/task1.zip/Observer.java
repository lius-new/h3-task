package chapter20.task1;

public interface Observer {
    void update();
}

package chapter18.task1;

public interface Store {

    MyIterator createIterator();
}

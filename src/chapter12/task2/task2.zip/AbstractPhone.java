package chapter12.task2;

public abstract class AbstractPhone {
    // 默认只有接受来电
    abstract void playCall();
}

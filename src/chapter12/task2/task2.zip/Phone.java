package chapter12.task2;

public class Phone extends AbstractPhone{
    @Override
    void playCall() {
        System.out.println("接受电话");
    }
}

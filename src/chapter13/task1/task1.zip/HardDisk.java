package chapter13.task1;

public class HardDisk {
    public boolean on() {
        System.out.println("硬盘读取");
        return true;
    }

}

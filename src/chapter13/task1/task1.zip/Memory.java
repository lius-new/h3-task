package chapter13.task1;

public class Memory {
    public boolean on(){
        System.out.println("内存检查");
        return true;
    }
}

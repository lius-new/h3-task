package chapter13.task1;

public class Cpu {
    public boolean on() {
        System.out.println("Cpu运行");
        return false;
    }
}

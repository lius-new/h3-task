package chapter14.task1;

public class Hub extends NetworkDevice{

    @Override
    String getType() {
        return "Hub";
    }
}

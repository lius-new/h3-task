package chapter14.task1;

public class Switch extends NetworkDevice{
    @Override
    String getType() {
        return "Switch";
    }
}

package chapter17.task1;

public abstract class AbstractGestureCommand {
    abstract void execute();
}

package chapter17.task1;

public class Gesture {
    public void inner(){
        System.out.println("向内一推");
    }
    public void outer(){
        System.out.println("向外一推");
    }
}

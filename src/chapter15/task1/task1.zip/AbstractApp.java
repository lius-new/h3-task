package chapter15.task1;

public abstract class AbstractApp {
    abstract void run();
}

package chapter15.task1;

public class QQApp extends AbstractApp {
    @Override
    void run() {
        System.out.println("点击qq启动程序,即将打开qq");
    }
}

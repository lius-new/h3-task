package chapter10.task2;

public abstract class Beverage {

}

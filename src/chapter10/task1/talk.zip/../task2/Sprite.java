package chapter10.task2;

public class Sprite implements Brand {
    @Override
    public void make(String type) {
        System.out.println(type + "雪碧饮料" + " . ");
    }
}

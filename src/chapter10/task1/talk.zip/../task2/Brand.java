package chapter10.task2;

public interface Brand {
    void make(String type);
}

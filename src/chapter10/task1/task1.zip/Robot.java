package chapter10.task1;

public interface Robot {
    void say();

    void run();
}

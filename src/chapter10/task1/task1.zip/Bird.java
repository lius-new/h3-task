package chapter10.task1;

public class Bird {
    public void say() {
        System.out.println("鸟叽叽喳喳");
    }
}

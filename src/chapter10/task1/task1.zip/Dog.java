package chapter10.task1;

public class Dog {
    public void run() {
        System.out.println("狗快快跑");
    }
}
